// Import required modules
const express = require("express");
const bodyParser = require("body-parser");
const puppeteer = require("puppeteer");
const mongoose = require("mongoose");
const path = require("path");
const fastcsv = require("fast-csv");
const cors = require("cors");
const fs = require("fs");
const ejs = require("ejs");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const cookieParser = require("cookie-parser");
const session = require("express-session");
const { url } = require("inspector");

const app = express();
app.use(cookieParser());
app.use(bodyParser.json());
app.use(cors());
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));

let dburl =
  "mongodb+srv://roameramit2001:roameramit2001@cluster0.amndb01.mongodb.net/?retryWrites=true&w=majority";
let dburlof = "mongodb://127.0.0.1/logindataAdmin";

mongoose
  .connect(dburlof, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("Db Connected");
  });

const domainemails = new mongoose.Schema({
  DomainName: { type: String },
  Email: { type: String, unique: true },
  createdAt: { type: Date, default: Date.now }, // Add createdAt field to store the creation date
  category: { type: String, default: "" }, // Add the "category" field of type String
});

const DomainEmail = mongoose.model("domainemails", domainemails);

// let browser;
// (async () => {
//     browser = await puppeteer.launch({ headless: false });
//     // const browser = await puppeteer.launch({
//     //   executablePath: '/path/to/chrome',
//     // });
//     const page = await browser.newPage();

//     const email = 'amitcarpenter198@gmail.com';
//     const password = '@mit93023';

//     await page.goto('https://www.google.com/');
//     // await page.waitForSelector('#username');
//     // await page.type('#username', email);
//     // await page.type('#password', password);
//     // await page.click('button[type="submit"]');
//     // await page.waitForNavigation();
// })();

// app.post('/scrape', async (req, res) => {
//     console.log("start");
//     try {
//         const page = await browser.newPage();
//         // Reuse the existing browser object
//         const profileUrl = req.body.url;
//         console.log('Scraping URL:', profileUrl);
//         await page.goto(profileUrl, { waitUntil: 'domcontentloaded' });
//         await page.waitForSelector('.pv-profile-section__section-info');

//         //  for Email
//         const emails = await page.evaluate(() => {
//             const divElement = document.querySelector('.pv-profile-section__section-info');
//             const textContent = divElement.textContent;
//             const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g;
//             const matches = textContent.match(emailRegex);
//             return matches ? matches[0] : null;
//         });
//         console.log(`Email: ${emails}`);

//         // for Profile Name
//         await page.waitForSelector('.text-heading-xlarge');
//         const profileName = await page.evaluate(() => {
//             const divElement = document.querySelector('.text-heading-xlarge');
//             return divElement.textContent.trim();
//         });
//         console.log(`Profile Name: ${profileName}`);

//         const profileData = {
//             Name: profileName,
//             Email: emails || '', // Use an empty string if emails is null
//         };

//         try {
//             // Check if the profile with the same Name or Email already exists in the database
//             const existingProfile = await ProfileModel.findOne({
//                 $or: [{ Name: profileName }, { Email: emails }],
//             });

//             if (existingProfile) {
//                 console.log('Profile with the same Name or Email already exists in the database. Updating existing profile...');
//                 // Perform an update operation for the existing profile
//                 await ProfileModel.findOneAndUpdate(
//                     { $or: [{ Name: profileName }, { Email: emails }] },
//                     { $set: { Name: profileName, Email: emails || '' } },
//                     { new: true } // Set this option to return the updated document
//                 );
//             } else {
//                 // Save the data to the database
//                 await ProfileModel.create(profileData);
//                 console.log('Data saved to the database.');
//             }

//             // ... Your other code ...
//         } catch (error) {
//             console.log("catch");
//             console.log(error);

//             if (error.code === 11000) {
//                 // Handle duplicate key error
//                 console.log('Duplicate key error. Profile with the same Name or Email already exists in the database.');
//             }

//             res.status(500).json({ error: 'An error occurred while scraping the URL.' });
//         }

//         const dataToWrite = `Email: ${profileName}\n`;
//         const dataToWrites = `Email: ${emails}\n`;
//         fs.writeFileSync('output.txt', dataToWrite, dataToWrites, { flag: 'a' });
//         console.log('Data stored in output.txt');

//         await page.close();
//         res.status(200).json({ message: 'Scraping successful.' });
//     } catch (error) {
//         console.log("catch");
//         console.log(error);
//         res.status(500).json({ error: 'An error occurred while scraping the URL.' });
//     }
//     console.log("end");
// });

// const puppeteer = require('puppeteer');

// (async () => {
//     // Launch a headless browser
//     const browser = await puppeteer.launch({ headless: false });

//     // Open a new page
//     const page = await browser.newPage();

//     // Go to Google
//     await page.goto('https://www.google.com');

//     // Enter your search keyword
//     await page.type('input[name=q]', 'srninfotech');

//     // Press Enter to initiate the search
//     await page.keyboard.press('Enter');

//     // Wait for the search results to load
//     await page.waitForSelector('.rc');

//     // Extract and click on the search results
//     const searchResults = await page.$$('.rc .r a');
//     for (const result of searchResults) {
//         await result.click();
//         // You can add additional logic here, like extracting data from the clicked page
//         await page.goBack(); // Go back to the search results page
//     }

//     // Close the browser
//     await browser.close();
// })();

// const puppeteer = require('puppeteer');

// (async () => {
//   // Launch a headless browser
//   const browser = await puppeteer.launch({headless : false});

//   // Open a new page
//   const page = await browser.newPage();

//   // Go to Google
//   await page.goto('https://www.google.com');

//   // Wait for the search input to be visible before typing
//   await page.waitForSelector('input[name=q]');

//   // Enter your search keyword
//   await page.type('input[name=q]', 'Your Keyword Here');

//   // Press Enter to initiate the search
//   await page.keyboard.press('Enter');

//   // Wait for the search results to load
//   await page.waitForSelector('.GyAeWb');

//   // Custom selector for the link you want to click
//   const linkSelector = '.yuRUbf div a';

//   // Evaluate and click the link with the custom selector
//   await page.evaluate((selector) => {
//     const link = document.querySelector(selector);
//     if (link) {
//         console.log("clikc")
//       link.click();
//     } else {
//       console.error('Link not found with selector:', selector);
//     }
//   }, linkSelector);

//   // You can add additional logic here, like extracting data from the clicked page

//   // Close the browser
//   await browser.close();
// })();

// const puppeteer = require('puppeteer');
// const fs = require('fs');

// (async () => {
//   const browser = await puppeteer.launch({ headless: false });
//   const page = await browser.newPage();

//   const websiteName = 'srninfotech'; // Replace with your website name
//   await page.goto('https://www.google.com');
//   await page.waitForSelector('input[name=q]');
//   await page.type('input[name=q]', websiteName);
//   await page.keyboard.press('Enter');

//   // Wait for the search results to load (wait for a more specific selector)
//   await page.waitForSelector('.tF2Cxc'); // This selector represents individual search results

//   // Extract and click on the first 10 search results
//   const searchResults = await page.$$('.tF2Cxc a');
//   for (let i = 0; i < 10 && i < searchResults.length; i++) {
//     const result = searchResults[i];
//     const link = await result.getProperty('href');
//     const linkText = await link.jsonValue();
//     console.log(`Opening page ${i + 1}: ${linkText}`);
//     await result.click();

//     // Wait for the page to load (you may need to adjust the waiting time)
//     await page.waitForTimeout(5000);

//     // Extract email addresses (this is a simplified example)
//     const pageContent = await page.content();
//     const emailRegex = /\S+@\S+\.\S+/g;
//     const emails = pageContent.match(emailRegex) || [];

//     // Store emails in a text file
//     if (emails.length > 0) {
//       const fileName = `emails_${i + 1}.txt`;
//       fs.writeFileSync(fileName, emails.join('\n'));
//       console.log(`Emails from page ${i + 1} saved in ${fileName}`);
//     }

//     // Go back to the search results page
//     await page.goBack();
//   }

//   await browser.close();
// })();

// const puppeteer = require('puppeteer');
// const fs = require('fs');
// const readline = require('readline');

// const rl = readline.createInterface({
//   input: process.stdin,
//   output: process.stdout,
// });

// const visitLinksSequentially = async (page, links, currentIndex) => {
//   if (currentIndex >= links.length || currentIndex >= 10) {
//     console.log('Finished scraping.');
//     return;
//   }

//   const link = links[currentIndex];

//   console.log(`Opening page ${currentIndex + 1}: ${link}`);
//   await page.goto(link);

//   // Wait for the page to load (you may need to adjust the waiting time)
//   await page.waitForTimeout(5000);

//   // Extract email addresses (this is a simplified example)
//   const pageContent = await page.content();
//   const emailRegex = /\S+@\S+\.\S+/g;
//   const emails = pageContent.match(emailRegex) || [];

//   // Store emails in a text file
//   if (emails.length > 0) {
//     const fileName = `emails_${currentIndex + 1}.txt`;
//     fs.writeFileSync(fileName, emails.join('\n'));
//     console.log(`Emails from page ${currentIndex + 1} saved in ${fileName}`);
//   }

//   // Go back to the search results page
//   await page.goBack();

//   // Continue to the next link
//   await visitLinksSequentially(page, links, currentIndex + 1);
// };

// // Ask the user for the website name
// rl.question('Enter the website name: ', async (websiteName) => {
//   rl.close();

//   const browser = await puppeteer.launch({ headless: false });
//   const page = await browser.newPage();

//   await page.goto('https://www.google.com');
//   await page.waitForSelector('input[name=q]');
//   await page.type('input[name=q]', websiteName);
//   await page.keyboard.press('Enter');

//   // Wait for the search results to load (wait for a more specific selector)
//   await page.waitForSelector('.tF2Cxc'); // This selector represents individual search results

//   // Extract and store the links of the first 10 search results
//   const searchResults = await page.$$('.tF2Cxc a');
//   const links = [];
//   for (let i = 0; i < 10 && i < searchResults.length; i++) {
//     const result = searchResults[i];
//     const link = await result.getProperty('href');
//     const linkText = await link.jsonValue();
//     links.push(linkText);
//   }

//   // Visit links sequentially and scrape emails
//   await visitLinksSequentially(page, links, 0);

//   await browser.close();
// });

// const puppeteer = require('puppeteer');
// const fs = require('fs');

// (async () => {
//     const browser = await puppeteer.launch({ headless: false });
//     const page = await browser.newPage();

//     const websiteName = 'srninfotech'; // Replace with your website name
//     await page.goto('https://www.google.com');
//     await page.waitForSelector('input[name=q]');
//     await page.type('input[name=q]', websiteName);
//     await page.keyboard.press('Enter');

//     // Wait for the search results to load (wait for a more specific selector)
//     await page.waitForSelector('.tF2Cxc'); // This selector represents individual search results

//     // Extract and store the links of the first 10 search results
//     const searchResults = await page.$$('.tF2Cxc a');
//     const links = [];
//     for (let i = 0; i < 70 && i < searchResults.length; i++) {
//         const result = searchResults[i];
//         const link = await result.getProperty('href');
//         const linkText = await link.jsonValue();
//         links.push(linkText);
//     }

//     // Function to visit links sequentially and scrape emails
//     const visitLinksSequentially = async (links) => {
//         for (let i = 0; i < links.length; i++) {
//             const link = links[i];
//             console.log(`Opening page ${i + 1}: ${link}`);
//             await page.goto(link);

//             // Wait for the page to load (you may need to adjust the waiting time)
//             await page.waitForTimeout(5000);

//             // Extract email addresses (this is a simplified example)
//             const pageContent = await page.content();
//             const emailRegex = /[\w\.=-]+@[\w\.-]+\.[\w]{2,3}/gim;
//             const emails = pageContent.match(emailRegex) || [];

//             // Store emails in a text file
//             if (emails.length > 0) {
//                 const fileName = `emails_${i + 1}.txt`;
//                 fs.writeFileSync(fileName, emails.join('\n'));
//                 console.log(`Emails from page ${i + 1} saved in ${fileName}`);
//             }

//             // Go back to the search results page
//             await page.goBack();
//         }
//     };

//     // Visit links sequentially and scrape emails
//     await visitLinksSequentially(links);

//     await browser.close();
// })();

// const puppeteer = require('puppeteer');
// const fs = require('fs');

// (async () => {
//   const browser = await puppeteer.launch({ headless: false });
//   const page = await browser.newPage();

//   const websiteName = 'srninfotech'; // Replace with your website name
//   await page.goto('https://www.google.com');
//   await page.waitForSelector('input[name=q]');
//   await page.type('input[name=q]', websiteName);
//   await page.keyboard.press('Enter');

//   // Wait for the search results to load (wait for a more specific selector)
//   await page.waitForSelector('.tF2Cxc'); // This selector represents individual search results

//   // Extract and store the links of the first 10 search results
//   const searchResults = await page.$$('.tF2Cxc a');
//   const links = [];
//   for (let i = 0; i < 5 && i < searchResults.length; i++) {
//     const result = searchResults[i];
//     const link = await result.getProperty('href');
//     const linkText = await link.jsonValue();
//     links.push(linkText);
//   }

//   // Function to visit links sequentially and scrape emails
//   const visitLinksSequentially = async (links) => {
//     const allEmails = []; // Collect all scraped emails in this array

//     for (let i = 0; i < links.length; i++) {
//       const link = links[i];
//       console.log(`Opening page ${i + 1}: ${link}`);
//       await page.goto(link);

//       // Wait for the page to load (you may need to adjust the waiting time)
//       await page.waitForTimeout(5000);

//       // Extract email addresses (this is a simplified example)
//       const pageContent = await page.content();
//       const emailRegex = /[\w\.=-]+@[\w\.-]+\.[\w]{2,3}/gim;
//       const emails = pageContent.match(emailRegex) || [];

//       // Add emails to the allEmails array
//       allEmails.push(...emails);

//       // Go back to the search results page
//       await page.goBack();
//     }

//     return allEmails; // Return all collected emails
//   };

//   // Visit links sequentially and scrape emails
//   const scrapedEmails = await visitLinksSequentially(links);

//   // Write all scraped emails to a single text file
//   fs.writeFileSync('all_emails.txt', scrapedEmails.join('\n'));

//   await browser.close();
// })();

// const puppeteer = require('puppeteer');
// const fs = require('fs');
// (async () => {
//     const browser = await puppeteer.launch({ headless: false });
//     const page = await browser.newPage();

//     const websiteName = 'srninfotech'; // Replace with your website name
//     await page.goto('https://www.google.com');
//     await page.waitForSelector('input[name=q]');
//     await page.type('input[name=q]', websiteName);
//     await page.keyboard.press('Enter');

//     // Wait for the search results to load (wait for a more specific selector)
//     await page.waitForSelector('.tF2Cxc'); // This selector represents individual search results

//     // Extract and store the links of the first 10 search results
//     const searchResults = await page.$$('.tF2Cxc a');
//     const links = [];
//     for (let i = 0; i < 10 && i < searchResults.length; i++) {
//         const result = searchResults[i];
//         const link = await result.getProperty('href');
//         const linkText = await link.jsonValue();

//         // Filter links that start with "https://"
//         if (linkText.startsWith('https://')) {
//             links.push(linkText);
//         }
//     }

//     // Function to scrape emails from a given page and save them immediately
//     const scrapeEmailsAndSave = async (link, index) => {
//         const newPage = await browser.newPage();
//         await newPage.goto(link);

//         // Wait for the page to load (you may need to adjust the waiting time)
//         await newPage.waitForTimeout(5000);

//         // Extract email addresses (this is a simplified example)
//         const pageContent = await newPage.content();
//         const emailRegex = /[\w\.=-]+@[\w\.-]+\.[\w]{2,3}/gim;
//         const emails = pageContent.match(emailRegex) || [];

//         // Save emails to a file or array immediately
//         if (emails.length > 0) {
//             const fileName = `emails_${index + 1}.txt`;
//             fs.writeFileSync(fileName, emails.join('\n'));
//             console.log(`Emails from page ${index + 1} saved in ${fileName}`);
//         }

//         await newPage.close();
//     };

//     // Loop through links and scrape emails from each page, saving them immediately
//     for (let i = 0; i < links.length; i++) {
//         await scrapeEmailsAndSave(links[i], i);
//     }

//     await browser.close();
// })();

(async () => {
  app.post("/scrape", async (req, res) => {
    // const browser = await puppeteer.launch({ headless: false });
    const browser = await puppeteer.launch({
      executablePath:
        "C:\\Program Files\\BraveSoftware\\Brave-Browser\\Application\\brave.exe", // Replace with the actual path to Brave browser executable
      headless: false,
      defaultViewport: false,
    });

    //   const browser = await puppeteer.launch({executablePath: '/path/to/Chrome'});
    const page = await browser.newPage();

    const profileUrl = req.body.url;
    const limitOfSearch = req.body.limitsearch;
    const Categroy = req.body.category;
    console.log(Categroy);
    console.log(limitOfSearch);
    console.log("Scraping URL:", profileUrl);
    const websiteName = "srninfotech";
    await page.goto(profileUrl);
    await page.waitForSelector("input[name=q]");
    await page.type("input[name=q]", websiteName);
    await page.keyboard.press("Enter");

    // Function to scroll the page and load more search results
    const scrollPage = async () => {
      await page.evaluate(() => {
        window.scrollBy(0, window.innerHeight + 8000); // Scroll down by one viewport height
      });
      await page.waitForTimeout(3000);
      // You can adjust the waiting time depending on your website's behavior
      await page.click(".kQdGHd");
      await page.waitForTimeout(3000); // Wait for 2 seconds after scrolling

      await page.evaluate(() => {
        window.scrollBy(0, window.innerHeight + 4000); // Scroll down by one viewport height
      });
      await page.waitForTimeout(3000);
      // You can adjust the waiting time depending on your website's behavior
      await page.click(".kQdGHd");
      await page.waitForTimeout(3000);

      await page.evaluate(() => {
        window.scrollBy(0, window.innerHeight + 4000); // Scroll down by one viewport height
      });
      await page.waitForTimeout(3000);
      // You can adjust the waiting time depending on your website's behavior
      await page.click(".kQdGHd");
      await page.waitForTimeout(3000);

      await page.evaluate(() => {
        window.scrollBy(0, window.innerHeight + 6000); // Scroll down by one viewport height
      });
      await page.waitForTimeout(3000);
      // You can adjust the waiting time depending on your website's behavior
      await page.click(".kQdGHd");
      await page.waitForTimeout(3000);

      await page.evaluate(() => {
        window.scrollBy(0, window.innerHeight + 7000); // Scroll down by one viewport height
      });
      await page.waitForTimeout(3000);
      // You can adjust the waiting time depending on your website's behavior
      await page.click(".kQdGHd");
      await page.waitForTimeout(3000);

      await page.evaluate(() => {
        window.scrollBy(0, window.innerHeight + 7000); // Scroll down by one viewport height
      });
      await page.waitForTimeout(3000);
      // You can adjust the waiting time depending on your website's behavior
      await page.click(".kQdGHd");
      await page.waitForTimeout(3000);

      await page.evaluate(() => {
        window.scrollBy(0, window.innerHeight + 7000); // Scroll down by one viewport height
      });
      await page.waitForTimeout(3000);
      // You can adjust the waiting time depending on your website's behavior
      await page.click(".kQdGHd");
      await page.waitForTimeout(3000);

      await page.evaluate(() => {
        window.scrollBy(0, window.innerHeight + 7000); // Scroll down by one viewport height
      });
      await page.waitForTimeout(3000);
      // You can adjust the waiting time depending on your website's behavior
      await page.click(".kQdGHd");
      await page.waitForTimeout(3000);

      await page.evaluate(() => {
        window.scrollBy(0, window.innerHeight + 7000); // Scroll down by one viewport height
      });
      await page.waitForTimeout(3000);
      // You can adjust the waiting time depending on your website's behavior
      await page.click(".kQdGHd");
      await page.waitForTimeout(3000);

      await page.evaluate(() => {
        window.scrollBy(0, window.innerHeight + 7000); // Scroll down by one viewport height
      });
      await page.waitForTimeout(3000);
      // You can adjust the waiting time depending on your website's behavior
      await page.click(".kQdGHd");
      await page.waitForTimeout(3000);

      await page.evaluate(() => {
        window.scrollBy(0, window.innerHeight + 7000); // Scroll down by one viewport height
      });
      await page.waitForTimeout(3000);
      // You can adjust the waiting time depending on your website's behavior
      await page.click(".kQdGHd");
      await page.waitForTimeout(3000);

      await page.evaluate(() => {
        window.scrollBy(0, window.innerHeight + 7000); // Scroll down by one viewport height
      });
      await page.waitForTimeout(3000);
      // You can adjust the waiting time depending on your website's behavior
      await page.click(".kQdGHd");
      await page.waitForTimeout(3000);

      await page.evaluate(() => {
        window.scrollBy(0, window.innerHeight + 7000); // Scroll down by one viewport height
      });
      await page.waitForTimeout(3000);
      // You can adjust the waiting time depending on your website's behavior
      await page.click(".kQdGHd");
      await page.waitForTimeout(3000);

      await page.evaluate(() => {
        window.scrollBy(0, window.innerHeight + 7000); // Scroll down by one viewport height
      });
      await page.waitForTimeout(3000);
      // You can adjust the waiting time depending on your website's behavior
      await page.click(".kQdGHd");
      await page.waitForTimeout(3000);
    };
    await scrollPage();
    // Wait for the search results to load (wait for a more specific selector)
    await page.waitForSelector(".tF2Cxc"); // This selector represents individual search results

    // Extract and store the links of the first 10 search results
    const searchResults = await page.$$(".tF2Cxc a");

    console.log(searchResults.length);

    const links = [];
    for (let i = 0; i < limitOfSearch && i < searchResults.length; i++) {
      const result = searchResults[i];
      const link = await result.getProperty("href");
      const linkText = await link.jsonValue();

      links.push(linkText);
    }

    // Function For Scrape The Email
    const scrapeEmails = async (link, maxExecutionTime = 200000) => {
      return new Promise(async (resolve, reject) => {
        const newPage = await browser.newPage();
        page.setDefaultTimeout(200000);

        const timeoutId = setTimeout(() => {
          // If the execution time exceeds maxExecutionTime, reject the promise
          newPage.close();
          browser.close();
          reject(
            new Error("Execution time exceeded the maximum allowed time.")
          );
        }, maxExecutionTime);

        try {
          await newPage.goto(link, { timeout: 200000 });

          // Wait for the page to load (you may need to adjust the waiting time)
          await newPage.waitForTimeout(5000);

          // Extract email addresses (this is a simplified example)
          const pageContent = await newPage.content();
          const emailRegex = /[\w\.=-]+@[\w\.-]+\.[\w]{2,3}/gim;
          // const emailRegex = /[\w\.=-]+@[^\d\W][\w\.-]+\.[\w]{2,3}/gim;

          const emails = pageContent.match(emailRegex) || [];
          // Function to extract domain from a URL
          const extractDomain = (url) => {
            let match;
            if (url.startsWith("http://www.")) {
              match = url.match(/http:\/\/www\.([^/]+)/);
            } else if (url.startsWith("https://www.")) {
              match = url.match(/https:\/\/www\.([^/]+)/);
            } else if (url.startsWith("http://")) {
              match = url.match(/http:\/\/([^/]+)/);
            } else if (url.startsWith("https://")) {
              match = url.match(/https:\/\/([^/]+)/);
            } else {
              return null; // Return null for unsupported URL format
            }

            if (match) {
              return match[1];
            }
            return null; // Return null if no match is found
          };

          // Get the current tab's URL
          const currentURL = await newPage.url();
          // console.log(currentURL)

          // Extract the domain from the current URL
          const currentDomain = extractDomain(currentURL);

          // Print the current domain
          console.log(`Current Domain: ${currentDomain}`);

          // Define the extensions to filter out
          const extensionsToFilter = [".png", ".jpg"]; // Add more extensions if needed

          // Filter out email addresses that end with any of the specified extensions
          const filteredEmails = emails.filter(
            (email) =>
              !extensionsToFilter.some((extension) => email.endsWith(extension))
          );

          const uniqueEmails = new Set(filteredEmails);

          for (const email of uniqueEmails) {
            // Check if the email already exists in the database
            const existingProfile = await DomainEmail.findOne({ Email: email });

            if (!existingProfile) {
              const EmailsSaveInDatabase = new DomainEmail({
                DomainName: currentDomain,
                Email: email,
                category: Categroy, // Set the category as needed
              });

              await EmailsSaveInDatabase.save();
            } else {
              console.log("Skip the Dublicate Email Amit");
            }
          }

          // Convert the Set back to an array
          const uniqueEmailsArray = Array.from(uniqueEmails);

          // Log the unique email addresses
          console.log(uniqueEmailsArray);

          await newPage.close();
          clearTimeout(timeoutId); // Clear the timeout since the function completed within the time limit

          resolve(uniqueEmailsArray); // Resolve with your result
          return uniqueEmailsArray;
        } catch (error) {
          // clearTimeout(timeoutId); // Clear the timeout in case of any errors
          reject(error); // Reject with the error
        }
      });
    };

    // Create a Set to store unique emails
    const uniqueEmails = new Set();

    console.log(links);
    // Loop through links and scrape emails from each page
    for (const link of links) {
      const emails = await scrapeEmails(link);

      // Add unique emails to the Set
      emails.forEach((email) => uniqueEmails.add(email));
    }

    // Convert the Set to an array and sort it if needed
    const uniqueEmailsArray = Array.from(uniqueEmails);

    // Write unique emails to a single text file
    fs.writeFileSync("unique_emails.txt", uniqueEmailsArray.join("\n"));

    await browser.close();
  });
})();

// (async () => {
//   const browser = await puppeteer.launch({ headless: false });
//   const page = await browser.newPage();

//   const websiteName = 'srninfotech'; // Replace with your website name
//   await page.goto('https://www.google.com');
//   await page.waitForSelector('input[name=q]');
//   await page.type('input[name=q]', websiteName);
//   await page.keyboard.press('Enter');

//   // Wait for the search results to load (wait for a more specific selector)
//   await page.waitForSelector('.tF2Cxc'); // This selector represents individual search results

//   // Extract and store the links of the first 10 search results
//   const searchResults = await page.$$('.tF2Cxc a');
//   const links = [];
//   for (let i = 0; i < 10 && i < searchResults.length; i++) {
//     const result = searchResults[i];
//     const link = await result.getProperty('href');
//     const linkText = await link.jsonValue();

//     // Filter links that start with "https://"
//     if (linkText.startsWith('https://')) {
//       links.push(linkText);
//     }
//   }

//   // Function to scrape emails from a given page and save them
//   const scrapeEmails = async (link) => {
//     const newPage = await browser.newPage();

//     page.setDefaultNavigationTimeout(60000);
//     // Set a timeout of 25 seconds (adjust as needed)
//     const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), 25000));

//     const navigationPromise = newPage.goto(link);

//     try {
//       // Race the navigation promise with the timeout promise
//       await Promise.race([navigationPromise, timeoutPromise]);

//       // Wait for the page to load (you may need to adjust the waiting time)
//       await newPage.waitForTimeout(5000);

//       // Extract email addresses (this is a simplified example)
//       const pageContent = await newPage.content();
//       const emailRegex = /\S+@\S+\.\S+/g;
//       const emails = pageContent.match(emailRegex) || [];

//       return emails;
//     } catch (error) {
//       console.error(`Error: ${error.message}`);
//       await newPage.close();
//       return []; // Return an empty array if there was a timeout or error
//     } finally {
//       await newPage.close();
//     }
//   };

//   // Create a Set to store unique emails
//   const uniqueEmails = new Set();

//   // Loop through links and scrape emails from each page
//   for (const link of links) {
//     const emails = await scrapeEmails(link);

//     // Add unique emails to the Set
//     emails.forEach((email) => uniqueEmails.add(email));
//   }

//   // Convert the Set to an array and sort it if needed
//   const uniqueEmailsArray = Array.from(uniqueEmails);

//   // Write unique emails to a single text file
//   fs.writeFileSync('unique_emails.txt', uniqueEmailsArray.join('\n'));

//   await browser.close();
// })();

// app.get('/export/csv', async (req, res) => {
//     try {
//         const profiles = await DomainEmail.find();

//         // Convert data to CSV format
//         const csvData = profiles.map(profile => [profile.Email]);

//         // Create a writable stream to store CSV data
//         const csvStream = fastcsv.format({ headers: ['Email'] });
//         const writableStream = fs.createWriteStream('dashboard.csv');

//         // Pipe the CSV data to the writable stream
//         csvStream.pipe(writableStream);
//         csvData.forEach(data => csvStream.write(data));
//         csvStream.end();

//         // Send the CSV file as a response
//         res.setHeader('Content-Type', 'text/csv');
//         res.setHeader('Content-Disposition', 'attachment; filename="dashboard.csv"');
//         fs.createReadStream('dashboard.csv').pipe(res);
//     } catch (error) {
//         console.error('Error occurred:', error);
//         res.status(500).send('Internal Server Error');
//     }
// });

// // Export to PDF route
// app.get('/export/pdf', async (req, res) => {
//     try {
//         const profiles = await DomainEmail.find();

//         // Render the EJS view to a HTML string
//         const html = await ejs.renderFile('views/index.ejs', { profiles });

//         // Removed Puppeteer code here

//         // Send the generated HTML as a response
//         res.setHeader('Content-Type', 'text/html');
//         res.send(html);
//     } catch (error) {
//         console.error('Error occurred:', error);
//         res.status(500).send('Internal Server Error');
//     }
// });

// app.get('/export/csv/company', async (req, res) => {
//     try {
//         const companyemails = await DomainEmail.find();

//         // Convert data to CSV format
//         const csvData = companyemails.map(companyemail => [companyemail.DomainName, companyemail.Email]);

//         // Create a writable stream to store CSV data
//         const csvStream = fastcsv.format({ headers: ['Name', 'Email'] });
//         const writableStream = fs.createWriteStream('dashboard.csv');

//         // Pipe the CSV data to the writable stream
//         csvStream.pipe(writableStream);
//         csvData.forEach(data => csvStream.write(data));
//         csvStream.end();

//         // Send the CSV file as a response
//         res.setHeader('Content-Type', 'text/csv');
//         res.setHeader('Content-Disposition', 'attachment; filename="dashboard.csv"');
//         fs.createReadStream('dashboard.csv').pipe(res);
//     } catch (error) {
//         console.error('Error occurred:', error);
//         res.status(500).send('Internal Server Error');
//     }
// });

// // Export to PDF route for company
// app.get('/export/pdf/company', async (req, res) => {
//     try {
//         const companyemails = await DomainEmail.find();

//         // Render the EJS view to a HTML string
//         const html = await ejs.renderFile('views/companyEmails.ejs', { companyemails });

//         res.setHeader('Content-Type', 'text/html');
//         res.send(html);
//     } catch (error) {
//         console.error('Error occurred:', error);
//         res.status(500).send('Internal Server Error');
//     }
// });

// Function to scrape emails from a given page and save them
// const scrapeEmails = async (link) => {
//     const newPage = await browser.newPage();
//     page.setDefaultTimeout(60000);
//     // await newPage.goto(link);
//     await newPage.goto(link, { timeout: 60000 }); // Set a specific timeout for this navigation

//     // await page.waitForNavigation({ waitUntil: 'networkidle0' });

//     // Wait for the page to load (you may need to adjust the waiting time)
//     await newPage.waitForTimeout(5000);

//     // Extract email addresses (this is a simplified example)
//     const pageContent = await newPage.content();
//     const emailRegex = /[\w\.=-]+@[\w\.-]+\.[\w]{2,3}/gim;
//     // const emailRegex = /[\D\w\.=-]+@[\w\.-]+\.[\w]{2,3}/gim;
//     const emails = pageContent.match(emailRegex) || [];

//     // ...

//     // Function to extract domain from a URL
//     const extractDomain = (url) => {
//         let match;
//         if (url.startsWith("http://www.")) {
//             match = url.match(/http:\/\/www\.([^/]+)/);
//         } else if (url.startsWith("https://www.")) {
//             match = url.match(/https:\/\/www\.([^/]+)/);
//         } else if (url.startsWith("http://")) {
//             match = url.match(/http:\/\/([^/]+)/);
//         } else if (url.startsWith("https://")) {
//             match = url.match(/https:\/\/([^/]+)/);
//         } else {
//             return null; // Return null for unsupported URL format
//         }

//         if (match) {
//             return match[1];
//         }
//         return null; // Return null if no match is found
//     };

//     // Get the current tab's URL
//     const currentURL = await newPage.url();
//     // console.log(currentURL)

//     // Extract the domain from the current URL
//     const currentDomain = extractDomain(currentURL);

//     // Print the current domain
//     console.log(`Current Domain: ${currentDomain}`);

//     // ...

//     // Define the extensions to filter out
//     const extensionsToFilter = [".png", ".jpg"]; // Add more extensions if needed

//     // Filter out email addresses that end with any of the specified extensions
//     const filteredEmails = emails.filter(email => !extensionsToFilter.some(extension => email.endsWith(extension)));

//     const uniqueEmails = new Set(filteredEmails);

//     // Convert the Set back to an array
//     const uniqueEmailsArray = Array.from(uniqueEmails);

//     // Log the unique email addresses
//     console.log(uniqueEmailsArray);

//     await newPage.close();

//     return uniqueEmailsArray;
// };

const port = 3000;
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});

const LocalStrategy = require("passport-local").Strategy;

exports.initializingPassport = (passport) => {

};

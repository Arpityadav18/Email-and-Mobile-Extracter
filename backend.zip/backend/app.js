const express = require("express");
const BodyParser = require("body-parser");
const mongoose = require("mongoose");
const ejs = require("ejs");
const cors = require("cors");
const path = require("path");
const app = express();
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const session = require("express-session");
const fs = require("fs");
const passport = require("passport");
const LocalStrategy = require("passport-local").Strategy;
const flash = require("connect-flash");
// const expressSession = require('express-session');
const { isLogin, isLogout } = require("./middleware/auth");

const jwtSecretKey = "AmitcarPenter";
const sessoinSecret = "hellomynameisamit";

// Middle ware
app.use(
  session({
    secret: sessoinSecret,
    resave: false, // Set resave option to false
    saveUninitialized: true, // Set saveUninitialized option to false
  })
);
// Middleware to set user email in the session
app.use((req, res, next) => {
  // Assuming you have the user's email in req.user.email after authentication
  if (req.user && req.user.email) {
    req.session.email = req.user.email;
    console.log("Session Data:", req.session);
  }
  next();
});
app.use(express.json());
app.use(BodyParser.json());
app.use(express.urlencoded({ extended: true }));
app.use(BodyParser.urlencoded({ extended: true }));
app.use(cors());
app.use("/css", express.static(path.join(__dirname, "../frontend/css")));
app.use("/icons", express.static(path.join(__dirname, "../frontend/icons")));
app.use("/images", express.static(path.join(__dirname, "../frontend/images")));
app.use("/js", express.static(path.join(__dirname, "../frontend/js")));
app.use(
  "/plugins",
  express.static(path.join(__dirname, "../frontend/plugins"))
);
app.use(express.static("public"));
app.use(flash());

app.use(passport.initialize());
app.use(passport.session());

// Set Engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "../frontend"));

let dburl =
  "mongodb+srv://roameramit2001:roameramit2001@cluster0.amndb01.mongodb.net/?retryWrites=true&w=majority";
let dburlof = "mongodb://127.0.0.1/logindataAdmin";
// Connect to database
mongoose
  .connect(dburl)
  .then(() => {
    console.log("DB Connected");
  })
  .catch((err) => {
    console.log(err);
    console.log("error in mongodb");
  });

// User Model
const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  isAdmin: {
    type: Number,
    default: 0,
  },
  secretCode: {
    type: String,
  },
});

const User = mongoose.model("user", userSchema);

// Emails Domain schema
const domainemails = new mongoose.Schema({
  user_id: { type: String },
  secretCode: { type: String },
  DomainName: { type: String },
  Email: { type: String, unique: true },
  createdAt: { type: Date, default: Date.now }, // Add createdAt field to store the creation date
  category: { type: String, default: "" }, // Add the "category" field of type String
});

const DomainEmail = mongoose.model("domainemails", domainemails);

//Category Schema
const categorySchema = new mongoose.Schema({
  category: {
    type: String,
    required: true,
    unique: true,
  },
});

const Category = mongoose.model("Category", categorySchema);

// Passport Local Strategy
// function isAuthenticated(req, res, next) {
//     if (req.isAuthenticated()) {
//       return next();
//     }
//     res.redirect('/'); // or handle unauthorized access appropriately
//   }

// passport.use(
//   new LocalStrategy(async (email, password, done) => {
//     const user = await User.findOne({ email });
//     if (!user) return done(null, false);
//     // Use bcrypt to compare the provided password with the hashed password in the database
//     const isPasswordValid = await bcrypt.compare(password, user.password);

//     if (!isPasswordValid) {
//       return done(null, false, { message: "Incorrect password." });
//     }

//     return done(null, user);
//   })
// );

// passport.serializeUser((user, done) => {
//   done(null, user.id);
// });

// passport.deserializeUser(async (id, done) => {
//   try {
//     const user = await User.findById(id);
//     done(null, user);
//   } catch (error) {
//     done(error, false);
//   }
// });

const securePassword = async (password) => {
  try {
    const passwordHash = await bcrypt.hash(password, 10);
    return passwordHash;
  } catch (error) {
    console.log(error.massage);
  }
};

// Generate Random String
function generateRandomString(length) {
  let result = "";
  const characters = "ABCDEFGHIJKLMPQRSTUVWXYZ1234";
  const charactersLength = characters.length;

  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }

  return result;
}

// Compare Password
const comparePasswords = async (plainPassword, hashedPassword) => {
  return await bcrypt.compare(plainPassword, hashedPassword);
};

// Routing

app.get("/fpwrd", isLogout, (req, res) => {
  res.render("page-lock", { error: null, successMessage: null });
});

// Change Password
app.post("/fpwrd", async (req, res) => {
  const { oldPassword, newPassword, confirmPassword } = req.body;
  console.log("new", newPassword);
  // Replace this with your authentication middleware to verify the user's session or token.
  // For this example, I'll assume you already have the user's information from authentication.
  const user = await User.findOne();

  if (!user) {
    return res.render("page-lock", { error: "User not found" });
  }

  const passwordMatch = await comparePasswords(oldPassword, user.password);
  if (!passwordMatch) {
    return res.render("page-lock", { error: "Invalid old password" });
  }

  if (newPassword !== confirmPassword) {
    return res.render("page-lock", {
      error: "New password and confirm password don't match",
    });
  }

  // Hash the new password using bcrypt.
  const newHashedPassword = await bcrypt.hash(newPassword, 10);

  // Replace the user's password with the new hashed password in the database.
  // In a real application, this should be done using your data storage mechanism (e.g., updating the user record in a database).
  user.password = newHashedPassword;
  await user.save();

  // Return a success response.
  console.log("changed");
  res.render("page-lock", {
    successMessage: "Password changed successfully",
    error: null,
  });
});

app.get("/api/user-info", async (req, res) => {
  try {
    const user_id = req.session.user_id;

    const userData = await User.findOne({ _id: user_id });
    if (!userData) {
      // If no user data is found, return a 404 Not Found response
      return res.status(404).json({ message: "User data not found" });
    }
    console.log(userData);
    res.status(200).json({ userData });
  } catch (error) {
    console.error(error);
    // Send a 500 Internal Server Error response for any unexpected error
    res.status(500).json({ message: "Internal server error" });
  }
});

// Login Page Loader
app.get("/", isLogout, (req, res) => {
  try {
    res.render("page-login");
  } catch (error) {
    console.log(error);
  }
});

// Login the User
app.post("/", async (req, res) => {
  const { email, password } = req.body;
  // console.log(email , password)
  try {
    const user = await User.findOne({ email });
    if (user) {
      const passwordMatch = await bcrypt.compare(password, user.password);
      if (passwordMatch) {
        req.session.user_id = user._id;

        if (user.isAdmin == 0) {
          console.log("Login Success Fully");
          const token = jwt.sign({ userId: user._id }, jwtSecretKey);
          return res.redirect("/dashboard");
        } else {
          console.log("Login Success Fully");
          const token = jwt.sign({ userId: user._id }, jwtSecretKey);
          return res.redirect("/admindashboard");
        }
      } else {
        return res.render("page-login", {
          massage: "Email and Password is Incorrect",
        });
      }
    } else {
      return res.render("page-login", {
        massage: "Email and Password is Incorrect",
      });
    }
  } catch (error) {
    console.log("eroor");
    console.error(error);
  }
});

// Register Page Loader
app.get("/add-user", (req, res) => {
  try {
    res.render("page-register");
  } catch (error) {
    console.log(error);
  }
});

//Register post api
app.post("/add-user", async (req, res) => {
  const { name, email, password } = req.body;
  console.log(req.body);
  try {
    // Check if the email is already registered
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(409).json({ error: "Email already registered." });
    }
    const hashedPassword = await securePassword(password);
    // Create a new user document and save it to the database
    const newUser = new User({
      name,
      email,
      password: hashedPassword,
      secretCode: generateRandomString(5),
    });
    await newUser.save();
    const token = jwt.sign({ userId: newUser._id }, "AMITCARPENTER");

    return res.status(201).redirect("/admindashboard");
  } catch (error) {
    console.error("Error registering user:", error);
    return res.status(500).json({ error: "Internal server error." });
  }
});

app.get("/admindashboard", isLogin, async (req, res) => {
  try {
    const user_id = req.session.user_id;

    // Get the current date
    const currentDate = new Date();

    // Calculate the start and end of today
    const startOfDay = new Date(currentDate);
    startOfDay.setHours(0, 0, 0, 0); // Set to the beginning of the day
    const endOfDay = new Date(currentDate);
    endOfDay.setHours(23, 59, 59, 999); // Set to the end of the day

    const todayFilter = {
      createdAt: {
        $gte: startOfDay,
        $lte: endOfDay,
      },
    };
    // Find data for today using the "createdAt" field
    const todayData = await DomainEmail.find(todayFilter);

    const todayEmails = todayData.length;

    // Calculate Current Week of the month
    const startOfWeek = new Date(currentDate);
    startOfWeek.setDate(currentDate.getDate() - currentDate.getDay() + 1);
    startOfWeek.setHours(0, 0, 0, 0);

    const endOfWeek = new Date(currentDate);
    endOfWeek.setDate(startOfWeek.getDate() + 6);
    endOfWeek.setHours(23, 59, 59, 999);

    const weekFilter = {
      createdAt: {
        $gte: startOfWeek,
        $lte: endOfWeek,
      },
    };
    // Find data for the current week using the "createdAt" field
    const weeklyData = await DomainEmail.find(weekFilter);
    const weeklyEmails = weeklyData.length;

    // calculte Current Month
    const startOfMonth = new Date(
      currentDate.getFullYear(),
      currentDate.getMonth(),
      1
    );
    // Calculate the end of the current month
    const endOfMonth = new Date(
      currentDate.getFullYear(),
      currentDate.getMonth() + 1,
      0
    );

    const MonthFilter = {
      createdAt: {
        $gte: startOfMonth,
        $lte: endOfMonth,
      },
    };

    // Find data for the current month using the "createdAt" field
    const monthlyData = await DomainEmail.find(MonthFilter);

    const MonthlyEmails = monthlyData.length;

    // Calculate Total Data
    const totaldata = await DomainEmail.find();
    const secretCodes = await DomainEmail.find({}, { secretCode: 1, _id: 0 });
    const totalEmails = totaldata.length;

    const userTable = await User.find();

    // Render the EJS template and pass the data as variables
    res.render("AdminIndex", {
      weeklyData,
      totalEmails,
      totaldata,
      todayData,
      todayEmails,
      monthlyData,
      weeklyEmails,
      MonthlyEmails,
      secretCodes,
      userTable,
    });
  } catch (error) {
    console.log(error);
  }
});

// Dashboard Page Loader
app.get("/dashboard", isLogin, async (req, res) => {
  try {
    const user_id = req.session.user_id;

    const userIdForDashboard = await User.find({ user_id: user_id });
    if (userIdForDashboard.isAdmin === "0") {
      console.log("hello");
    }
    // Get the current date
    const currentDate = new Date();

    // Calculate the start and end of today
    const startOfDay = new Date(currentDate);
    startOfDay.setHours(0, 0, 0, 0); // Set to the beginning of the day
    const endOfDay = new Date(currentDate);
    endOfDay.setHours(23, 59, 59, 999); // Set to the end of the day

    const todayFilter = {
      createdAt: {
        $gte: startOfDay,
        $lte: endOfDay,
      },
    };

    // Add user_id to the filter
    if (user_id) {
      todayFilter.user_id = user_id;
    }

    // Find data for today using the "createdAt" field
    const todayData = await DomainEmail.find(todayFilter);

    const todayEmails = todayData.length;

    // Calculate Current Week of the month
    const startOfWeek = new Date(currentDate);
    startOfWeek.setDate(currentDate.getDate() - currentDate.getDay() + 1);
    startOfWeek.setHours(0, 0, 0, 0);

    const endOfWeek = new Date(currentDate);
    endOfWeek.setDate(startOfWeek.getDate() + 6);
    endOfWeek.setHours(23, 59, 59, 999);

    const weekFilter = {
      createdAt: {
        $gte: startOfWeek,
        $lte: endOfWeek,
      },
    };

    // Add user_id to the filter
    if (user_id) {
      weekFilter.user_id = user_id;
    }

    // Find data for the current week using the "createdAt" field
    const weeklyData = await DomainEmail.find(weekFilter);
    const weeklyEmails = weeklyData.length;

    // calculte Current Month
    const startOfMonth = new Date(
      currentDate.getFullYear(),
      currentDate.getMonth(),
      1
    );
    // Calculate the end of the current month
    const endOfMonth = new Date(
      currentDate.getFullYear(),
      currentDate.getMonth() + 1,
      0
    );

    const MonthFilter = {
      createdAt: {
        $gte: startOfMonth,
        $lte: endOfMonth,
      },
    };
    if (user_id) {
      MonthFilter.user_id = user_id;
    }
    // Find data for the current month using the "createdAt" field
    const monthlyData = await DomainEmail.find(MonthFilter);

    const MonthlyEmails = monthlyData.length;

    // Calculate Total Data
    const totaldata = await DomainEmail.find({ user_id: user_id });

    // const totaldata = await DomainEmail.find({ userId: req.user._id });

    const totalEmails = totaldata.length;

    // Render the EJS template and pass the data as variables
    res.render("index", {
      weeklyData,
      totalEmails,
      totaldata,
      todayData,
      todayEmails,
      monthlyData,
      weeklyEmails,
      MonthlyEmails,
    });
  } catch (error) {
    console.log(error);
  }
});

// Email Inbox Page Loader
app.get("/email-inbox", (req, res) => {
  try {
    res.render("email-inbox");
  } catch (error) {
    console.log(error);
  }
});

// Email Read Page Loader
app.get("/email-read", (req, res) => {
  try {
    res.render("email-read");
  } catch (error) {
    console.log(error);
  }
});

// Email Compose Page Loader
app.get("/email-compose", (req, res) => {
  try {
    res.render("email-compose");
  } catch (error) {
    console.log(error);
  }
});

//Data Table Page Loader
app.get("/table-datatable", (req, res) => {
  try {
    res.render("table-datatable");
  } catch (error) {
    console.log(error);
  }
});

//Api for Date Filter
/// Filter by date For Website
app.get("/filterDatabydate", async (req, res) => {
  try {
    const startDate = new Date(req.query.startDate);

    const endDate = new Date(req.query.endDate);
    endDate.setHours(23, 59, 59, 999);

    const user_id = req.session.user_id;
    const filterbydate = {
      createdAt: {
        $gte: startDate,
        $lt: endDate,
      },
    };

    // Add user_id to the filter
    // if (user_id) {
    //   filterbydate.user_id = user_id;
    // }
    // Fetch the data from the database based on the date range
    const filteredData = await DomainEmail.find(filterbydate);
    res.json(filteredData);
  } catch (error) {
    console.error("Error occurred:", error);
    res.status(500).json({ error: "An unexpected error occurred." });
  }
});

// Filter by day For |Website
app.get("/filterDatabyday", async (req, res) => {
  try {
    const selectedDate = new Date(req.query.selectedDate);
    console.log(selectedDate);

    // Set the startDate to the beginning of the selected day (00:00:00)
    const startDate = new Date(selectedDate);
    startDate.setHours(0, 0, 0, 0);

    // Set the endDate to the end of the selected day (23:59:59)
    const endDate = new Date(selectedDate);
    endDate.setHours(23, 59, 59, 999);

    const filterbyday = {
      createdAt: {
        $gte: startDate,
        $lte: endDate,
      },
    };

    // Fetch the data from the database for the specified day
    const filteredData = await DomainEmail.find(filterbyday);

    res.json(filteredData);
  } catch (error) {
    console.error("Error occurred:", error);
    res.status(500).json({ error: "An unexpected error occurred." });
  }
});
// app.get("/filterDatabyday", async (req, res) => {
//   try {
//     const selectedDate = new Date(req.query.selectedDate);
//     console.log(selectedDate);

//     // Set the startDate to the beginning of the selected day (00:00:00)
//     const startDate = new Date(selectedDate);
//     startDate.setHours(0, 0, 0, 0);

//     // Set the endDate to the end of the selected day (23:59:59)
//     const endDate = new Date(selectedDate);
//     endDate.setHours(23, 59, 59, 999);

//     const user_id = req.session.user_id;
//     const filterbyday = {
//       createdAt: {
//         $gte: startDate,
//         $lte: endDate,
//       },
//     };

//     // Add user_id to the filter
//     if (user_id) {
//       filterbyday.user_id = user_id;
//     }
//     // Fetch the data from the database for the specified day
//     const filteredData = await DomainEmail.find(filterbyday);

//     res.json(filteredData);
//   } catch (error) {
//     console.error("Error occurred:", error);
//     res.status(500).json({ error: "An unexpected error occurred." });
//   }
// });

// POST Route For Both
app.post("/api/categories", (req, res) => {
  const { category } = req.body;
  console.log(category);
  // Validate the request body
  if (!category) {
    return res
      .status(400)
      .json({ error: "Name and description are required." });
  }

  // Create a new category using the Category model
  const newCategory = new Category({
    category,
  });

  // Save the new category to the database
  newCategory
    .save()
    .then((savedCategory) => res.status(201).json(savedCategory))
    .catch((err) => {
      res.status(500).json({ error: "Failed to create category." });
      console.log(err);
    });
});

// Get the Category  for Both
app.get("/api/categories", async (req, res) => {
  // Use the Category model to find all categories in the database
  await Category.find()
    .then((categories) => {
      res.json(categories);
    })
    .catch((err) =>
      res.status(500).json({ error: "Failed to fetch categories." })
    );
});

// Delete Category
app.delete("/api/categories", async (req, res) => {
  let categoryValues = req.query.selectedCategory; // Assuming 'selectedCategory' is either an array or a comma-separated string
  console.log(categoryValues);

  try {
    let selectedCategoryArray;

    if (Array.isArray(categoryValues)) {
      selectedCategoryArray = categoryValues;
    } else if (typeof categoryValues === "string") {
      // Split the comma-separated string into an array
      selectedCategoryArray = categoryValues.split(",");
    } else {
      return res.status(400).json({
        success: false,
        message:
          "Invalid input. selectedCategory should be an array or a comma-separated string.",
      });
    }

    console.log(selectedCategoryArray);

    // Delete categories based on their values
    const result = await Category.deleteMany({
      category: { $in: selectedCategoryArray },
    });

    if (result.deletedCount === 0) {
      return res
        .status(404)
        .json({ success: false, message: "Categories not found." });
    }

    return res.json({
      success: true,
      message: "Categories deleted successfully.",
    });
  } catch (error) {
    console.error("Error while deleting categories:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while deleting the categories.",
    });
  }
});

// Filter the data date and category in website Emails
app.get("/filterdateandcategory", async (req, res) => {
  try {
    const selectedCategories = req.query.selectedCategory;
    console.log(selectedCategories);

    let selectedCategoryArray;

    selectedCategoryArray = Array.isArray(selectedCategories)
      ? selectedCategories
      : [selectedCategories];

    if (typeof selectedCategories === "string") {
      // Split the comma-separated string into an array
      selectedCategoryArray = selectedCategories.split(",");
    }
    const startDate = new Date(req.query.startDate);
    const endDate = new Date(req.query.endDate);

    // Set the endDate to the end of the selected day (23:59:59)
    endDate.setHours(23, 59, 59, 999);

    // Create the query object with 'category' and 'createdAt' fields

    const user_id = req.session.user_id;
    const filterbycategory = {
      category: { $in: selectedCategoryArray },
      createdAt: {
        $gte: startDate,
        $lt: endDate,
      },
    };

    // Add user_id to the filter
    // if (user_id) {
    //   filterbycategory.user_id = user_id;
    // }

    // Fetch the data from the database based on the category and date range
    const filteredData = await DomainEmail.find(filterbycategory);

    res.json(filteredData);
  } catch (error) {
    console.error("Error occurred:", error);
    res.status(500).json({ error: "An unexpected error occurred." });
  }
});

// Filter By Data by Category  For Website
app.get("/api/filterDatabyCategory", async (req, res) => {
  const selectedCategories = req.query.selectedCategory;
  console.log(selectedCategories);
  try {
    let selectedCategoryArray;

    selectedCategoryArray = Array.isArray(selectedCategories)
      ? selectedCategories
      : [selectedCategories];

    if (typeof selectedCategories === "string") {
      // Split the comma-separated string into an array
      selectedCategoryArray = selectedCategories.split(",");
    }
    // selectedCategoryArray = selectedCategoryArray.split(',');
    // console.log(selectedCategoryArray)

    // Create the query object with the 'category' field
    const user_id = req.session.user_id;
    const filterbycategory = {
      category: { $in: selectedCategoryArray },
    };

    // Add user_id to the filter
    // if (user_id) {
    //   filterbycategory.user_id = user_id;
    // }

    // Create the query object with the 'category' field
    // Create the query object with the 'category' field
    // const query = { category: { $in: selectedCategory } };
    // Perform the query to get the filtered data
    const filteredData = await DomainEmail.find(filterbycategory);
    res.json(filteredData);
  } catch (error) {
    console.error("Error occurred:", error);
    res
      .status(500)
      .json({ error: "An unexpected error occurred. Please try again later." });
  }
});

//Delete Row
app.delete("/domainEmail/:id", async (req, res) => {
  try {
    const id = req.params.id;
    // Find the profile by ID and delete it from the database
    const deletedProfile = await DomainEmail.findByIdAndDelete(id);
    if (!deletedProfile) {
      return res.status(404).json({ message: "Profile not found" });
    }
    res.json({ message: "Profile deleted successfully", deletedProfile });
  } catch (error) {
    console.error("Error occurred:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

// Save Doamin emails in data base
app.post("/api/save-emails", async (req, res) => {
  const { Email, DomainName, category, secretCode } = req.body;

  console.log(secretCode);
  if (secretCode == undefined) {
    const user_id = req.session.user_id || "Guest";
    console.log(req.session);
    const existingLead = await DomainEmail.findOne({ Email: Email });
    // console.log(existingLead);
    const UserData = await User.findOne({ _id: user_id });

    console.log(UserData);
    console.log(UserData.id);
    // const user_id = UserData._id;
    // console.log(UserData);
    const secretCode = UserData.secretCode;

    if (existingLead) {
      // If the email exists, render the error EJS template
      return res
        .status(400)
        .json({ success: false, message: "Duplicate email" });
    }

    const newEmail = new DomainEmail({
      user_id: user_id,
      DomainName: DomainName,
      Email: Email,
      category: category,
      secretCode: secretCode,
    });
    await newEmail.save();

    console.log("Emails saved successfully to the database!");
    return res.json({ message: "Emails saved successfully to the database" });
  } else {
    const existingLead = await DomainEmail.findOne({ Email: Email });
    // console.log(existingLead);
    const UserData = await User.findOne({ secretCode: secretCode });

    console.log(UserData);
    console.log(UserData.id);
    const user_id = UserData._id;
    // console.log(UserData);
    // const secretCodex = UserData.secretCode;

    if (existingLead) {
      // If the email exists, render the error EJS template
      return res
        .status(400)
        .json({ success: false, message: "Duplicate email" });
    }

    const newEmail = new DomainEmail({
      user_id: user_id,
      DomainName: DomainName,
      Email: Email,
      category: category,
      secretCode: secretCode,
    });
    await newEmail.save();

    console.log("Emails saved successfully to the database!");
    return res.json({ message: "Emails saved successfully to the database" });
  }
});

// app.post("/api/save-emails", async (req, res) => {
//   try {
//     const { Email, DomainName, category, secretCode } = req.body;

//     // Check if the secretCode provided in the request body exists in the database
//     const user = await User.findOne({ secretCode: secretCode });

//     if (!user) {
//       return res.status(400).json({ success: false, message: "Invalid secretCode" });
//     }

//     const user_id = user._id; // Retrieve the user's _id from the database

//     const existingLead = await DomainEmail.findOne({ Email: Email });

//     if (existingLead) {
//       // If the email exists, render the error EJS template
//       return res.status(400).json({ success: false, message: "Duplicate email" });
//     }

//     const newEmail = new DomainEmail({
//       user_id: user_id,
//       DomainName: DomainName,
//       Email: Email,
//       category: category,
//     });

//     await newEmail.save();

//     console.log("Emails saved successfully to the database!");
//     return res.json({ message: "Emails saved successfully to the database" });
//   } catch (error) {
//     console.error(error);
//     return res.status(500).json({ success: false, message: "Internal server error" });
//   }
// });

// Logout
app.get("/logout", isLogin, async (req, res) => {
  try {
    req.session.destroy();
    console.log("Logout");
    return res.redirect("/");
  } catch (error) {
    console.log(error);
  }
});

//Profile Loader
app.get("/Profile", isLogin, async (req, res) => {
  try {
    res.render("app-profile");
  } catch (error) {
    console.log(error);
  }
});

// Filter data btoth in website emails  day and category
app.get("/api/filterDataboth", async (req, res) => {
  const selectedCategories = req.query.selectedCategory;
  console.log(selectedCategories);

  let selectedCategoryArray;

  selectedCategoryArray = Array.isArray(selectedCategories)
    ? selectedCategories
    : [selectedCategories];

  if (typeof selectedCategories === "string") {
    // Split the comma-separated string into an array
    selectedCategoryArray = selectedCategories.split(",");
  }
  const selectedDate = new Date(req.query.selectedDate);

  // Set the startDate to the beginning of the selected day (00:00:00)
  const startDate = new Date(selectedDate);
  startDate.setHours(0, 0, 0, 0);

  // Set the endDate to the end of the selected day (23:59:59)
  const endDate = new Date(selectedDate);
  endDate.setHours(23, 59, 59, 999);

  try {
    // Create the query object with both 'category' and 'createdAt' fields

    const user_id = req.session.user_id;
    const filterboth = {
      category: { $in: selectedCategoryArray },
      createdAt: {
        $gte: startDate,
        $lte: endDate,
      },
    };

    // // Add user_id to the filter
    // if (user_id) {
    //   filterboth.user_id = user_id;
    // }

    // Perform the query to get the filtered data
    const filteredData = await DomainEmail.find(filterboth);

    res.json(filteredData);
  } catch (error) {
    console.error("Error occurred:", error);
    res
      .status(500)
      .json({ error: "An unexpected error occurred. Please try again later." });
  }
});

app.listen(4000, () => {
  console.log("Server is working on 4000 ");
});

// "engines": {
//     "node": ">=14.20.1"
// },

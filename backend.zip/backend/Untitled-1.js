// Email Inbox Page Loader
app.get("/email-inbox", (req, res) => {
  try {
    res.render("email-inbox");
  } catch (error) {
    console.log(error);
  }
});

// Email Read Page Loader
app.get("/email-read", (req, res) => {
  try {
    res.render("email-read");
  } catch (error) {
    console.log(error);
  }
});

// Email Compose Page Loader
app.get("/email-compose", (req, res) => {
  try {
    res.render("email-compose");
  } catch (error) {
    console.log(error);
  }
});

//Data Table Page Loader
app.get("/table-datatable", (req, res) => {
  try {
    res.render("table-datatable");
  } catch (error) {
    console.log(error);
  }
});

// Filter by date For Website
app.get("/filterDatabydate", async (req, res) => {
  try {
    const startDate = new Date(req.query.startDate);

    const endDate = new Date(req.query.endDate);
    endDate.setHours(23, 59, 59, 999);
    // Fetch the data from the database based on the date range
    const filteredData = await DomainEmail.find({
      createdAt: {
        $gte: startDate,
        $lt: endDate,
      },
    });
    res.json(filteredData);
  } catch (error) {
    console.error("Error occurred:", error);
    res.status(500).json({ error: "An unexpected error occurred." });
  }
});

// Filter by day For |Website
app.get("/filterDatabyday", async (req, res) => {
  try {
    const selectedDate = new Date(req.query.selectedDate);
    console.log(selectedDate);

    // Set the startDate to the beginning of the selected day (00:00:00)
    const startDate = new Date(selectedDate);
    startDate.setHours(0, 0, 0, 0);

    // Set the endDate to the end of the selected day (23:59:59)
    const endDate = new Date(selectedDate);
    endDate.setHours(23, 59, 59, 999);

    // Fetch the data from the database for the specified day
    const filteredData = await DomainEmail.find({
      createdAt: {
        $gte: startDate,
        $lte: endDate,
      },
    });

    res.json(filteredData);
  } catch (error) {
    console.error("Error occurred:", error);
    res.status(500).json({ error: "An unexpected error occurred." });
  }
});

// POST Route For Both
app.post("/api/categories", (req, res) => {
  const { category } = req.body;
  console.log(category);
  // Validate the request body
  if (!category) {
    return res
      .status(400)
      .json({ error: "Name and description are required." });
  }

  // Create a new category using the Category model
  const newCategory = new Category({
    category,
  });

  // Save the new category to the database
  newCategory
    .save()
    .then((savedCategory) => res.status(201).json(savedCategory))
    .catch((err) => {
      res.status(500).json({ error: "Failed to create category." });
      console.log(err);
    });
});

// Get the Category  for Both
app.get("/api/categories", async (req, res) => {
  // Use the Category model to find all categories in the database
  await Category.find()
    .then((categories) => {
      res.json(categories);
    })
    .catch((err) =>
      res.status(500).json({ error: "Failed to fetch categories." })
    );
});

// Delete Category
app.delete("/api/categories", async (req, res) => {
  let categoryValues = req.query.selectedCategory; // Assuming 'selectedCategory' is either an array or a comma-separated string
  console.log(categoryValues);

  try {
    let selectedCategoryArray;

    if (Array.isArray(categoryValues)) {
      selectedCategoryArray = categoryValues;
    } else if (typeof categoryValues === "string") {
      // Split the comma-separated string into an array
      selectedCategoryArray = categoryValues.split(",");
    } else {
      return res.status(400).json({
        success: false,
        message:
          "Invalid input. selectedCategory should be an array or a comma-separated string.",
      });
    }

    console.log(selectedCategoryArray);

    // Delete categories based on their values
    const result = await Category.deleteMany({
      category: { $in: selectedCategoryArray },
    });

    if (result.deletedCount === 0) {
      return res
        .status(404)
        .json({ success: false, message: "Categories not found." });
    }

    return res.json({
      success: true,
      message: "Categories deleted successfully.",
    });
  } catch (error) {
    console.error("Error while deleting categories:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while deleting the categories.",
    });
  }
});

// Filter the data date and category in website Emails
app.get("/filterdateandcategory", async (req, res) => {
  try {
    const selectedCategories = req.query.selectedCategory;
    console.log(selectedCategories);

    let selectedCategoryArray;

    selectedCategoryArray = Array.isArray(selectedCategories)
      ? selectedCategories
      : [selectedCategories];

    if (typeof selectedCategories === "string") {
      // Split the comma-separated string into an array
      selectedCategoryArray = selectedCategories.split(",");
    }
    const startDate = new Date(req.query.startDate);
    const endDate = new Date(req.query.endDate);

    // Set the endDate to the end of the selected day (23:59:59)
    endDate.setHours(23, 59, 59, 999);

    // Create the query object with 'category' and 'createdAt' fields
    const query = {
      category: { $in: selectedCategoryArray },
      createdAt: {
        $gte: startDate,
        $lt: endDate,
      },
    };

    // Fetch the data from the database based on the category and date range
    const filteredData = await DomainEmail.find(query);

    res.json(filteredData);
  } catch (error) {
    console.error("Error occurred:", error);
    res.status(500).json({ error: "An unexpected error occurred." });
  }
});

// Filter By Data by Category  For Website
app.get("/api/filterDatabyCategory", async (req, res) => {
  const selectedCategories = req.query.selectedCategory;
  console.log(selectedCategories);
  try {
    let selectedCategoryArray;

    selectedCategoryArray = Array.isArray(selectedCategories)
      ? selectedCategories
      : [selectedCategories];

    if (typeof selectedCategories === "string") {
      // Split the comma-separated string into an array
      selectedCategoryArray = selectedCategories.split(",");
    }
    // selectedCategoryArray = selectedCategoryArray.split(',');
    // console.log(selectedCategoryArray)

    // Create the query object with the 'category' field
    const query = { category: { $in: selectedCategoryArray } };

    // Create the query object with the 'category' field
    // Create the query object with the 'category' field
    // const query = { category: { $in: selectedCategory } };
    // Perform the query to get the filtered data
    const filteredData = await DomainEmail.find(query);
    res.json(filteredData);
  } catch (error) {
    console.error("Error occurred:", error);
    res
      .status(500)
      .json({ error: "An unexpected error occurred. Please try again later." });
  }
});

//Delete Row
app.delete("/domainEmail/:id", async (req, res) => {
  try {
    const id = req.params.id;
    // Find the profile by ID and delete it from the database
    const deletedProfile = await DomainEmail.findByIdAndDelete(id);
    if (!deletedProfile) {
      return res.status(404).json({ message: "Profile not found" });
    }
    res.json({ message: "Profile deleted successfully", deletedProfile });
  } catch (error) {
    console.error("Error occurred:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

// Save Doamin emails in data base
app.post("/api/save-emails", async (req, res) => {
  const { Email, DomainName, category } = req.body;

  console.log(category);
  const existingLead = await DomainEmail.findOne({ Email: Email });

  if (existingLead) {
    // If the email exists, render the error EJS template
    return res.status(400).json({ success: false, message: "Duplicate email" });
  }

  const newEmail = new DomainEmail({
    DomainName: DomainName,
    Email: Email,
    category: category,
  });
  await newEmail.save();

  console.log("Emails saved successfully to the database!");
  return res.json({ message: "Emails saved successfully to the database" });
});

//Profile Loader
app.get("/Profile", async (req, res) => {
  try {
    res.render("app-profile");
  } catch (error) {
    console.log(error);
  }
});

// Filter data btoth in website emails  day and category
app.get("/api/filterDataboth", async (req, res) => {
  const selectedCategories = req.query.selectedCategory;
  console.log(selectedCategories);

  let selectedCategoryArray;

  selectedCategoryArray = Array.isArray(selectedCategories)
    ? selectedCategories
    : [selectedCategories];

  if (typeof selectedCategories === "string") {
    // Split the comma-separated string into an array
    selectedCategoryArray = selectedCategories.split(",");
  }
  const selectedDate = new Date(req.query.selectedDate);

  // Set the startDate to the beginning of the selected day (00:00:00)
  const startDate = new Date(selectedDate);
  startDate.setHours(0, 0, 0, 0);

  // Set the endDate to the end of the selected day (23:59:59)
  const endDate = new Date(selectedDate);
  endDate.setHours(23, 59, 59, 999);

  try {
    // Create the query object with both 'category' and 'createdAt' fields
    const query = {
      category: { $in: selectedCategoryArray },
      createdAt: {
        $gte: startDate,
        $lte: endDate,
      },
    };

    // Perform the query to get the filtered data
    const filteredData = await DomainEmail.find(query);

    res.json(filteredData);
  } catch (error) {
    console.error("Error occurred:", error);
    res
      .status(500)
      .json({ error: "An unexpected error occurred. Please try again later." });
  }
});


// Lock Page Loader
app.get("/lock", (req, res) => {
  try {
    res.render("page-lock");
  } catch (error) {
    console.log(error);
  }
});



// //Register post api
// app.post("/register", async (req, res) => {
//   const { name, email, password } = req.body;
//   console.log(req.body);
//   try {
//     // Check if the email is already registered
//     const existingUser = await User.findOne({ email });
//     if (existingUser) {
//       return res.status(409).json({ error: "Email already registered." });
//     }
//     const hashedPassword = await securePassword(password);
//     // Create a new user document and save it to the database
//     const newUser = new User({ name, email, password: hashedPassword });
//     await newUser.save();
//     const token = jwt.sign({ userId: newUser._id }, "AMITCARPENTER");

//     return res
//       .status(201)
//       .json({ message: "Registration successful!", user: newUser });
//   } catch (error) {
//     console.error("Error registering user:", error);
//     return res.status(500).json({ error: "Internal server error." });
//   }
// });
// Register a new user
// app.post("/register", (req, res) => {
//   try {
//     // Create a new user with name, email, and password
//     const newUser = new User({
//       name: req.body.name,
//       email: req.body.email,
//       username: req.body.email, // Set the username to the email
//     });

//     // Register the new user
//     User.register(newUser, req.body.password, (err, user) => {
//       console.log("in register");
//       if (err) {
//         console.error(err);
//         // Log the error message
//         console.error("Registration Error:", err.message);
//         console.log("error im me");

//         // Redirect to the registration page with an error message
//         return res.redirect(
//           "/register?error=" + encodeURIComponent(err.message)
//         );
//       }
//       console.log("unser else");
//       // Authenticate the user after successful registration
//       passport.authenticate("local", (err, user, info) => {
//         if (err) {
//           console.error(err);
//           return res.redirect(
//             "/register?error=" + encodeURIComponent(err.message)
//           );
//         }
//         if (!user) {
//           console.error("Authentication failed:", info.message);
//           return res.redirect(
//             "/register?error=" + encodeURIComponent(info.message)
//           );
//         }
//         req.logIn(user, (loginErr) => {
//           if (loginErr) {
//             console.error("Login failed:", loginErr);
//             return res.redirect(
//               "/register?error=" + encodeURIComponent(loginErr.message)
//             );
//           }
//           console.log("Authentication successful");
//           res.redirect("/dashboard");
//         });
//       })(req, res);
//     });
//   } catch (error) {
//     console.log("catch");
//     console.log(error);
//   }
// });




// Logout ..//
// app.get("/logout", async (req, res) => {
//   try {
//     //   req.session.destroy()
//     console.log("Logout");
//     return res.redirect("/");
//   } catch (error) {
//     console.log(error);
//   }
// });
// Log out
app.get("/logout", (req, res) => {
  req.logout();
  res.redirect("/");
});


// // Login the User
// app.post("/", async (req, res) => {
//   const { email, password } = req.body;
//   // console.log(email , password)
//   try {
//     const user = await User.findOne({ email });
//     if (user) {
//       const passwordMatch = await bcrypt.compare(password, user.password);
//       if (passwordMatch) {
//         req.session.user_id = user._id;
//         console.log("Login Success Fully");
//         const token = jwt.sign({ userId: user._id }, jwtSecretKey);
//         return res.redirect("/dashboard");
//       } else {
//         return res.render("page-login", {
//           massage: "Email and Password is Incorrect",
//         });
//       }
//     } else {
//       return res.render("page-login", {
//         massage: "Email and Password is Incorrect",
//       });
//     }
//   } catch (error) {
//     console.log("eroor");
//     console.error(error);
//   }
// });

const securePassword = async (password) => {
  try {
    const passwordHash = await bcrypt.hash(password, 10);
    return passwordHash;
  } catch (error) {
    console.log(error.massage);
  }
};


//Middleware Function with possport
function ensureAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    // User is authenticated, proceed
    return next();
  }
  // User is not authenticated, redirect to login page
  res.redirect("/login");
}




// Extract Domain from the Url
// function extractDomainNameFromUrl(url) {
//   try {
//     const urlObject = new URL(url);
//     let domainName = urlObject.hostname;
//     const parts = domainName.split('.');

//     // Find the index of "www" in the domain parts
//     const wwwIndex = parts.findIndex(part => part.toLowerCase() === 'www');
    
//     // Take the part of the domain name that comes after "www"
//     if (wwwIndex !== -1 && wwwIndex + 1 < parts.length) {
//       domainName = parts.slice(wwwIndex + 1).join('.');
//       // alert(domainName)
//     }
    
//     return domainName;
//   } catch (error) {
//     console.error('Invalid URL:', error.message);
//     return null;
//   }
// }










// Scrape the Emails
// function scrapeEmailAddresses(domainName) {
//   // Get the current tab's URL
//   chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
//     const currentTab = tabs[0];
//     const currentUrl = currentTab.url;

    

// fetch(currentUrl)
//   .then((response) => response.text())  
//   .then((htmlContent) => {
//     const emailRegex = /[\w\.=-]+@[\w\.-]+\.[\w]{2,3}/gim;
//     let emails = htmlContent.match(emailRegex);
//     if (emails == null) {
//       const emailListElement = document.getElementById("emailList");
//       emailListElement.innerHTML = ""; // Clear previous results
//       const listItem = document.createElement("li");
//       listItem.textContent = "No email addresses found on this page.";
//       emailListElement.appendChild(listItem);
//     }
    
//     let uniqueEmails = new Set(); // Create a set to store unique email addresses

//     // Convert domain name to lowercase for case-insensitive comparison
//     const lowercaseDomainName = domainName.toLowerCase();

//     // Filter the emails by domain name
//     if (domainName) {
//       const filteredEmails = emails.filter((email) => {
//         const lowercaseEmail = email.toLowerCase(); // Convert email to lowercase
//         return lowercaseEmail.endsWith(`@${lowercaseDomainName}`) || lowercaseEmail.endsWith('gmail.com');
//       });
//       emails = filteredEmails;
//     }

//     // Add the email addresses to the set to ensure uniqueness
//     if (emails && emails.length > 0) {
//       for (const email of emails) {
//         uniqueEmails.add(email);
//       }
//     }


//         const emailListElement = document.getElementById("emailList");
//         emailListElement.innerHTML = ""; // Clear previous results

//         if (uniqueEmails.size > 0) {
//           for (const email of uniqueEmails) {
//             const listItem = document.createElement("li");
//             listItem.textContent = email;

//             // Add a class to the list item for styling purposes
//             listItem.classList.add("email-list-item");

//             const addButton = document.createElement("button");
//             addButton.textContent = "Add to List";

//             // Function to check if the email exists in the databases and update the button color
//             const checkEmailExistence = (email) => {
//               // Make a request to check if the email exists in the ProfileModel database
//               fetch('https://srnlead.onrender.com/api/find-profile-emails', {
//                 method: 'POST',
//                 headers: {
//                   'Content-Type': 'application/json',
//                 },
//                 body: JSON.stringify({ domainName, email }), // Send the domainName and email as the request payload
//               })
//                 .then((response) => response.json())
//                 .then((data) => {
//                   const profileEmailExists = data.emailss.includes(email);

//                   // Make a request to check if the email exists in the DomainEmail database
//                   fetch('https://srnlead.onrender.com/api/find-domain-emails', {
//                     method: 'POST',
//                     headers: {
//                       'Content-Type': 'application/json',
//                     },
//                     body: JSON.stringify({ domainName, email }), // Send the domainName and email as the request payload
//                   })
//                     .then((response) => response.json())
//                     .then((data) => {
//                       const domainEmailExists = data.emailss.includes(email);

//                       if (profileEmailExists || domainEmailExists) {
//                         addButton.style.display = 'none'; // Change the button color to red when the email exists
//                         addButton.disabled = true; // Disable the button if the email is in either of the databases
//                       }

//                       addButton.addEventListener("click", () => {
//                         addButton.style.display = 'none';
//                         if (!addButton.disabled) {
                       
                 
//                             saveEmailToDatabase(email);
                       
//                         }
//                       });

//                       // Append the button to the right side of the list item
//                       listItem.appendChild(addButton);
//                       emailListElement.appendChild(listItem);
//                     })
//                     .catch((error) => {
//                       console.error("Error checking domain email existence:", error);
//                     });
//                 })
//                 .catch((error) => {
//                   console.error("Error checking profile email existence:", error);
//                 });
//             };

//             // Call the function to check if the email exists in the databases and update the button color
//             checkEmailExistence(email);
//           }
//         } else {
//           const listItem = document.createElement("li");
//           listItem.textContent = "No email addresses found on this page.";
//           emailListElement.appendChild(listItem);
//         }
//       })
//       .catch((error) => {
//         console.error("Error fetching page content:", error);
//         chrome.runtime.sendMessage({ emails: [] }); // Send an empty array in case of an error
//       });
//   });
// }






// Save Data tyo database
// async function saveEmailToDatabase(email) {
//   chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
//     const currentTab = tabs[0];
//     const currentUrl = currentTab.url;
//     const domainName = extractDomainNameFromUrl(currentUrl);

//         // Get the dropdown element by its ID
// const dropdown = document.getElementById('categoryDropdown');

// // Get the selected option element
// const selectedOption = dropdown.options[dropdown.selectedIndex];

// // Get the value of the selected category
// const selectedCategory = selectedOption.value;

// // You can also get the text content of the selected option if needed
// const category = selectedOption.textContent;

// localStorage.setItem('category', category);

   

//     if (domainName !== 'linkedin.com') {
//       // Save data for domains other than linkedin.com
//       fetch('https://srnlead.onrender.com/api/save-emails', {
//         method: 'POST',
//         headers: {
//           'Content-Type': 'application/json',
//         },
//         body: JSON.stringify({ DomainName: domainName, Email: email ,category:category}),
//       })
//         .then((response) => {
//           if (response.ok) {
//             console.log('Email saved successfully to the database!');
//           } else {
//             console.error('Failed to save email to the database.');
//           }
//         })
//         .catch((error) => {
//           console.error('Error saving email:', error);
//         });
//     } else {
//       // Save data specifically for linkedin.com
//       // Add your code here to save the specific data for linkedin.com
//       // Example:
//       fetch('https://srnlead.onrender.com/api/save-linkedin-data', {
//         method: 'POST',
//         headers: {
//           'Content-Type': 'application/json',
//         },
//         body: JSON.stringify({  Email: email, category:category  }),
//       })
//         .then((response) => {
//           if (response.ok) {
//             console.log('LinkedIn data saved successfully to the database!');
//           } else {
//             console.error('Failed to save LinkedIn data to the database.');
//           }
//         })
//         .catch((error) => {
//           console.error('Error saving LinkedIn data:', error);
//         });
//     }
//   });
// }




  // Function to log the current tab's domain name 
  // function logCurrentTabDomainAndScrapeEmails() {
  //   // Get the current tab's URL
  //   chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
  //     const currentTab = tabs[0];
  //     const currentUrl = currentTab.url;
  
  //     // Extract the domain name from the URL
  //     const domainName = extractDomainNameFromUrl(currentUrl);
  //     if (domainName) {
  //       console.log("Current Tab Domain Name:", domainName);
  
  //       // Update the popup.html to display the current tab's URL and domain name
  //       // document.getElementById("currentTabUrl").textContent = currentUrl;
  //       document.getElementById("currentTabDomain").textContent = domainName;
  
  //       // Scrape email addresses for the domain
  //       scrapeEmailAddresses(domainName);
  //     }
  //   });
  // }


  
// Call the function
  // document.addEventListener("DOMContentLoaded", function () {
  //   document.getElementById("extensionButton").addEventListener("click", logCurrentTabDomainAndScrapeEmails);
  
  //   // Add a delay before executing logCurrentTabDomainAndScrapeEmails to ensure that content script is loaded
  //   setTimeout(logCurrentTabDomainAndScrapeEmails, 100);
  // });



// For get the category and create the Category
    document.addEventListener('DOMContentLoaded', () => {
      const dropdown = document.getElementById('categoryDropdown');
      const secretCodeInput = document.getElementById('secretCode');
  
      
  
      // Function to fetch categories from the backend API
      function fetchCategories() {
        fetch('https://emails-lead.onrender.com/api/categories')
          .then((response) => response.json())
          .then((categories) => {

            const previouslySelectedCategory = localStorage.getItem('category');
            // Populate options for each category
            categories.forEach((category) => {
              const optionElement = document.createElement('option');
              optionElement.value = category._id;
              optionElement.innerText = category.category;

                  if (category.category === previouslySelectedCategory) {
            optionElement.setAttribute('selected', 'selected');
          }
              dropdown.appendChild(optionElement);
            });
          })
          .catch((error) => console.error('Error fetching categories:', error));
      }
  
      // Function to handle "Add Category" button click
      // function addCategory() {
      //   const newCategoryName = prompt("Enter the name of the new category:");
      //   if (newCategoryName) {
      //     const newCategory = { category: newCategoryName };
  
      //     fetch('https://emails-lead.onrender.com//api/categories', {
      //       method: 'POST',
      //       headers: {
      //         'Content-Type': 'application/json',
      //       },
      //       body: JSON.stringify(newCategory),
      //     })
      //       .then((response) => {
      //         if (response.ok) {
      //           alert('New category added successfully!');
      //           // Clear the current dropdown options
      //           dropdown.innerHTML = '';
      //           // Fetch categories again and repopulate the dropdown
      //           fetchCategories();
      //         } else {
      //           alert('Failed to add the new category. Please try again.');
      //         }
      //       })
      //       .catch((error) => {
      //         console.error('Error adding category:', error);
      //         alert('An error occurred while adding the category. Please try again.');
      //       });
      //   }
      // }
  
      // Fetch categories and populate the dropdown on page load
      fetchCategories();

        // Get the previously selected category from local storage
  
      // Attach click event listener to the "Add Category" button
    
      
    });




  // Demo this
    // document.addEventListener('DOMContentLoaded', () => {
    //   const dropdown = document.getElementById('categoryDropdown');
   

    
    //   // Get the previously selected category from local storage
    //   const previouslySelectedCategory = localStorage.getItem('selectedCategory');
    
    //   // Set the previously selected category as the selected value of the dropdown
    //   if (previouslySelectedCategory) {
    //     dropdown.value = previouslySelectedCategory;
    //   }
    
    //   // Attach click event listener to the "Add Category" button
  
    // });
    




  document.getElementById("ApplyId").addEventListener("click" ,function(){
    
// document.addEventListener('DOMContentLoaded', function () {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    var currentTab = tabs[0];
    var currentUrl = currentTab.url;


const limitsearchlist  =document.getElementById("number").value


            // Get the dropdown element by its ID
const dropdown = document.getElementById('categoryDropdown');

// Get the selected option element
const selectedOption = dropdown.options[dropdown.selectedIndex];

// Get the value of the selected category
const selectedCategory = selectedOption.value;

// You can also get the text content of the selected option if needed
const category = selectedOption.textContent;

localStorage.setItem('category', category);


    // Send the current URL to your backend server for scraping
    fetch('http://localhost:3000/scrape', { // Replace with your server URL
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        url: currentUrl,
        limitsearch: limitsearchlist ,
        category : category
        

  

      })
    }).then((response) => response.json())
      .then((data) => console.log(data))
      .catch((error) => console.error('Error:', error));
  });
});




























































  // Listen for messages from the content script and display the scraped email addresses in popup.html
  // chrome.runtime.onMessage.addListener(function (message) {
  //   const emailListElement = document.getElementById("emailList");
  //   emailListElement.innerHTML = ""; // Clear previous results
  
  //   if (message.emails && message.emails.length > 0) {
  //     for (const email of message.emails) {
  //       const listItem = document.createElement("li");
  //       listItem.textContent = email;
  //       emailListElement.appendChild(listItem);
  //     }
  //   } else {
  //     const listItem = document.createElement("li");
  //     listItem.textContent = "No email addresses found on this page.";
  //     emailListElement.appendChild(listItem);
  //   }
  // });
  


































  
  // Function to scrape email addresses from the webpage for a specific domain
//   function scrapeEmailAddresses(domainName) {
//     // Get the current tab's URL
//     chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
//       const currentTab = tabs[0];
//       const currentUrl = currentTab.url;
  
//       // Fetch the current tab's content
//       fetch(currentUrl)
//         .then((response) => response.text())
//         .then((htmlContent) => {
//           const emailRegex = /[\w\.=-]+@[\w\.-]+\.[\w]{2,3}/gim;
//           let emails = htmlContent.match(emailRegex);
//   // alert(emails)
//           // alert(emails)
//           // Filter the emails by domain name
//           if (domainName) {
//             const filteredEmails = emails.filter((email) => email.endsWith(`@${domainName}`));
//             emails = filteredEmails;
//             // alert(emails)
//             const emailListElement = document.getElementById("emailList");
//             emailListElement.innerHTML = ""; // Clear previous results
          
//             // Display all the emails in the list
//             if (emails) {
//               for (const email of emails) {
//                 const listItem = document.createElement("li");
//                 listItem.textContent = email;
//                 emailListElement.appendChild(listItem);
//               }
//             } else {
//               const listItem = document.createElement("li");
//               listItem.textContent = "No email addresses found on this page.";
//               emailListElement.appendChild(listItem);
//             }
//           }
  
//           // Send the filtered email addresses to the popup.js
//     //       const emailListElement = document.getElementById("emailList");
//     // emailListElement.innerHTML = ""; // Clear previous results
  
//     // if (emails) {
//     //   for (const email of   emails) {
//     //     const listItem = document.createElement("li");
//     //     listItem.textContent = email;
//     //     emailListElement.appendChild(listItem);
//     //   }
//     // } else {
//     //   const listItem = document.createElement("li");
//     //   listItem.textContent = "No email addresses found on this page.";
//     //   emailListElement.appendChild(listItem);
//     // }
//           // chrome.runtime.sendMessage({ emails });
//         })
//         .catch((error) => {
//           console.error("Error fetching page content:", error);
//           chrome.runtime.sendMessage({ emails: [] }); // Send an empty array in case of an error
//         });

//   // ... (previous code remains the same) ...

// // Fetch the current tab's content
// // fetch(currentUrl)
// // .then((response) => response.text())
// // .then((htmlContent) => {
// //   const emailRegex = /[\w\.=-]+@[\w\.-]+\.[\w]{2,3}/gim;
// //   let emails = htmlContent.match(emailRegex);
// //   alert(emails)

// //   // Filter the emails by domain name
// //   if (domainName) {
// //     const filteredEmails = emails.filter((email) => email.endsWith(`@${domainName}`));
// //     emails = filteredEmails;
// //     alert(emails)
// //   }

// //   // Send the filtered email addresses to the popup.js
  

// //   chrome.runtime.sendMessage({ emails });
// // })
// // .catch((error) => {
// //   console.error("Error fetching page content:", error);
// //   chrome.runtime.sendMessage({ emails: [] }); // Send an empty array in case of an error
// // });

// // ... (remaining code) ...

//     });
//   }
  


















// // Function to extract domain name from URL
// function extractDomainNameFromUrl(url) {
//     try {
//       const urlObject = new URL(url);
//       return urlObject.hostname;
//     } catch (error) {
//       console.error('Invalid URL:', error.message);
//       return null;
//     }
//   }
  
//   // Function to scrape email addresses from the webpage for a specific domain
//   function scrapeEmailAddresses(domainName) {
//     // Get the current tab's URL
//     chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
//       const currentTab = tabs[0];
//       const currentUrl = currentTab.url;
  
//       // Fetch the current tab's content
//       fetch(currentUrl)
//         .then((response) => response.text())
//         .then((htmlContent) => {
//           const emailRegex = /[\w\.=-]+@[\w\.-]+\.[\w]{2,3}/gim;
//           let emails = htmlContent.match(emailRegex);
  
//           console.log(emails)
//           // Filter the emails by domain name
//           console.log(domainName)
//           alert(domainName)
//           if (domainName) {
//             const filteredEmails = emails.filter((email) => email.endsWith(`@${domainName}`));
//             emails = filteredEmails;
//             console.log(emails)
//           }
  
//           // Send the filtered email addresses to the popup.js
//           chrome.runtime.sendMessage({ emails });
//         })
//         .catch((error) => {
//           console.error("Error fetching page content:", error);
//           chrome.runtime.sendMessage({ emails: [] }); // Send an empty array in case of an error
//         });
//     });
//   }
  
//   // Function to log the current tab's domain name and scrape email addresses for that domain
//   function logCurrentTabDomainAndScrapeEmails() {
//     // Get the current tab's URL
//     chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
//       const currentTab = tabs[0];
//       const currentUrl = currentTab.url;
  
//       // Extract the domain name from the URL
//       const domainName = extractDomainNameFromUrl(currentUrl);
  
//       // Check if the domain name is not null and log it to the console
//       if (domainName) {
//         console.log("Current Tab Domain Name:", domainName);
  
//         // Update the popup.html to display the current tab's URL and domain name
//         document.getElementById("currentTabUrl").textContent = currentUrl;
//         document.getElementById("currentTabDomain").textContent = domainName;
  
//         // Scrape email addresses for the domain
//         scrapeEmailAddresses(domainName);
//       }
//     });
//   }
  
//   // Call the function to log the current tab's domain name and scrape email addresses when the extension icon is clicked
//   document.addEventListener("DOMContentLoaded", function () {
//     document.getElementById("extensionButton").addEventListener("click", logCurrentTabDomainAndScrapeEmails);
//   });
  
//   // Listen for messages from the content script and display the scraped email addresses in popup.html
//   chrome.runtime.onMessage.addListener(function (message) {
//     const emailListElement = document.getElementById("emailList");
//     emailListElement.innerHTML = ""; // Clear previous results
  
//     if (message.emails && message.emails.length > 0) {
//       for (const email of message.emails) {
//         const listItem = document.createElement("li");
//         listItem.textContent = email;
//         emailListElement.appendChild(listItem);
//       }
//     } else {
//       const listItem = document.createElement("li");
//       listItem.textContent = "No email addresses found on this page.";
//       emailListElement.appendChild(listItem);
//     }
//   });
  
























// // Function to log the current tab's domain name and scrape email addresses for that domain
// function logCurrentTabDomainAndScrapeEmails() {
//     // Get the current tab's URL
//     chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
//         const currentTab = tabs[0];
//         const currentUrl = currentTab.url;

//         // Function to extract domain name from URL
//         function extractDomainNameFromUrl(url) {
//             try {
//                 const urlObject = new URL(url);
//                 return urlObject.hostname;
//             } catch (error) {
//                 console.error('Invalid URL:', error.message);
//                 return null;
//             }
//         }

//         // Extract the domain name from the URL
//         const domainName = extractDomainNameFromUrl(currentUrl);

//         // Check if the domain name is not null and log it to the console
//         if (domainName) {
//             console.log("Current Tab Domain Name:", domainName);

//             // Update the popup.html to display the current tab's URL and domain name
//             document.getElementById("currentTabUrl").textContent = currentUrl;
//             document.getElementById("currentTabDomain").textContent = domainName;

//             // Function to scrape email addresses from the webpage for a specific domain
//             function scrapeEmailAddresses(domainName) {
//                 // ... (rest of the code remains the same)
//             }

//             // Scrape email addresses for the domain
//             scrapeEmailAddresses(domainName);
//         }


//     });
// }

// // Call the function to log the current tab's domain name and scrape email addresses when the extension icon is clicked
// document.addEventListener("DOMContentLoaded", function () {
//     document.getElementById("extensionButton").addEventListener("click", logCurrentTabDomainAndScrapeEmails);
// });




// document.addEventListener("DOMContentLoaded", function () {
//     document.getElementById("extensionButton").addEventListener("click", async () => {
//       let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
//       chrome.scripting.executeScript({
//         target: { tabId: tab.id },
//         func: scrapeEmailDomainsFromPage,
//         args: [{ url: tab.url }],
//       });
//     });
//   });
  



  


// function scrapeEmailDomainsFromPage({ url }) {
//     fetch(url)
//       .then((response) => response.text())
//       .then((htmlContent) => {
//         const emailRegex = /[\w\.=-]+@[\w\.-]+\.[\w]{2,3}/gim;
//         let emails = htmlContent.match(emailRegex);
//         console.log(emails)
  
//         // Filter the emails by domain name (example: "example.com")
//         const domainToFilter = "srninfotech.com"; // Replace this with the desired domain
//         if (domainToFilter) {
//           const filteredEmails = emails.filter((email) => email.endsWith(`@${domainToFilter}`));
//           emails = filteredEmails;
//           console.log(emails)
//         }
  
//         // Send the filtered email addresses to the popup.js
//         chrome.runtime.sendMessage({ emails });
//       })
//       .catch((error) => {
//         console.error("Error fetching page content:", error);
//         chrome.runtime.sendMessage({ emails: [] }); // Send an empty array in case of an error
//       });
//   }
  


